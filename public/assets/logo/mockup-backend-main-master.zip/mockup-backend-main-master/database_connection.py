from sqlalchemy import create_engine, MetaData
from sqlalchemy.orm import sessionmaker


# Paramètres de connexion à la base de données
username = "dash_owner"
password = "go2M0XpEItOk"
host = "ep-curly-art-a52hpqfw.us-east-2.aws.neon.tech"
port = "5432"  # Port PostgreSQL par défaut
database = "dash"
ssl_mode = "require"

# URL de connexion
DATABASE_URL = f"postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}?sslmode={ssl_mode}"

# Création de l'engine pour SQLAlchemy
engine = create_engine(DATABASE_URL)

# Importez `Base` uniquement lorsque nécessaire.
def get_base():
    from model.model import Base
    return Base

# Configuration de la session locale
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Fonction pour récupérer une session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Création de l'objet MetaData
metadata = MetaData()

# Fonction pour tester la connexion
def test_connection():
    """
    Teste la connexion à la base de données et affiche les tables disponibles.
    """
    try:
        with engine.connect() as connection:
            metadata.reflect(bind=engine)
            print("Connexion réussie à la base de données.")
            
            # Affichage des tables présentes dans la base de données
            print("Tables dans la base de données :")
            for table_name in metadata.tables.keys():
                print(f"- {table_name}")
    except Exception as e:
        print("Erreur de connexion :", e)

# Fonction pour tester une requête sur un modèle
def test_query():
    """
    Teste une requête sur le modèle VisualFeature (par exemple).
    """
    from model.model import VisualFeature  # Import retardé pour éviter les dépendances circulaires
    session = SessionLocal()
    try:
        # Exemple de requête : récupérer toutes les entrées du modèle VisualFeature
        results = session.query(VisualFeature).all()
        for result in results:
            print(result)
    except Exception as e:
        print("Erreur de requête :", e)
    finally:
        session.close()

# Test de connexion si ce fichier est exécuté directement
if __name__ == "__main__":
    print("=== Test de connexion à la base de données ===")
    test_connection()
    print("\n=== Test de requête sur VisualFeature ===")
    test_query()
