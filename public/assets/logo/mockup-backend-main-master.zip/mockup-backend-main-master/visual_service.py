from typing import List
from sqlalchemy.orm import Session
from sqlalchemy import or_
from fastapi.templating import Jinja2Templates

# Importation des modèles et de la connexion à la base de données
from model.model import Keyword, VisualFeature
from database_connection import SessionLocal

# Configuration des templates Jinja2
templates = Jinja2Templates(directory="templates")

# Fonction pour comparer les caractéristiques avec les mots-clés de la base de données
def compare_features_with_keywords(features: dict, db: Session, request):
    """
    Compare les caractéristiques fournies avec les mots-clés dans la base de données.

    Args:
        features (dict): Les caractéristiques à comparer (par ex. businessdomain, time, role).
        db (Session): Session de base de données SQLAlchemy.
        request: Objet de requête FastAPI (nécessaire pour TemplateResponse).

    Returns:
        TemplateResponse: Une réponse HTML rendue avec les données du graphique.
    """
    matched_keywords = {
        "businessdomain": [],
        "time": [],
        "role": []
    }

    for key, values in features.items():
        if values:
            # Recherche des mots-clés correspondant dans la base de données
            db_keywords = db.query(Keyword).filter(
                Keyword.keyword_type == key
            ).filter(
                or_(*[Keyword.keyword_value.ilike(f"%{value}%") for value in values])
            ).all()

            # Collecte des valeurs correspondantes
            for keyword in db_keywords:
                matched_keywords[key].append(keyword.keyword_value)

    # Exemple de données pour un graphique
    x_data = ["January", "February", "March"]
    y_data = [12, 19, 3]

    return templates.TemplateResponse("chart.html", {
        "request": request,
        "visual_type": "line",
        "x_data": x_data,
        "y_data": y_data
    })

# Fonction pour obtenir les caractéristiques visuelles correspondantes
def get_visual_features(features: dict, db: Session, request):
    """
    Récupère les caractéristiques visuelles correspondantes depuis la base de données.

    Args:
        features (dict): Les caractéristiques à rechercher.
        db (Session): Session de base de données SQLAlchemy.
        request: Objet de requête FastAPI.

    Returns:
        dict: Données du graphique.
    """
    matched_keywords = {
        "businessdomain": [],
        "time": [],
        "role": []
    }

    for key, values in features.items():
        if values:
            # Recherche des mots-clés correspondant dans la base de données
            db_keywords = db.query(Keyword).filter(
                Keyword.keyword_type == key
            ).filter(
                or_(*[Keyword.keyword_value.ilike(f"%{value}%") for value in values])
            ).all()

            # Collecte des valeurs correspondantes
            for keyword in db_keywords:
                matched_keywords[key].append(keyword.keyword_value)

    # Exemple de données pour un graphique
    x_data = ["January", "February", "March"]
    y_data = [12, 19, 3]

    return {
        "request": request,
        "visual_type": "line",
        "x_data": x_data,
        "y_data": y_data
    }

# Fonction pour obtenir les caractéristiques visuelles par domaine
def get_visuals_by_domain(db: Session, business_domain: str, role: str) -> List[VisualFeature]:
    """
    Récupère les caractéristiques visuelles associées à un domaine d'activité.

    Args:
        db (Session): Session de base de données SQLAlchemy.
        business_domain (str): Domaine d'activité recherché.
        role (str): Rôle correspondant.

    Returns:
        List[VisualFeature]: Liste des caractéristiques visuelles trouvées.
    """
    visuals_from_db = db.query(VisualFeature).filter(
        VisualFeature.business_domain == business_domain
    ).all()
    return visuals_from_db
