import random
from model import BusinessDomain, Indicator, SessionLocal, Visual, VisualFeature, VisualGroup, VisualType

# Create a sample visual feature
def add_sample_visual_feature():
    db = SessionLocal()
    sample_visual = VisualFeature(
        indicator ="Sales trends",
        visual_type="bar_chart",
        data={"x_data": ["Q1", "Q2", "Q3"], "y_data": [10, 20, 30]},
        title="Quarterly Sales",
        position=1,
        priority=1,
        business_domain="marketing"
    )

    sample_visual = VisualFeature(
        indicator ="Sales trends",
        visual_type="bar_chart",
        data={"x_data": ["M1", "M2", "M3"], "y_data": [10, 20, 30]},
        title="Monthly Sales",
        time="Month",
        position=2,
        priority=1,
        business_domain="marketing"
    )
    db.add(sample_visual)
    db.commit()
    db.refresh(sample_visual)
    print(f"Added visual: {sample_visual.title}")

#add_sample_visual_feature()

def populate_visual_types_and_indicators():
    db = SessionLocal()
    visual_types = ["kpi", "bar_chart", "line_chart", "pie_chart"]
    indicators = ["TOTAL Sales", "Monthly Sales", "Quarterly Sales", "Customer Segmentation"]
    business = ["Sales", "Marketing", "HR", "Production"]
    
    """ # Insert business
    for b in business:
        db.add(BusinessDomain(business_domain_name=b))
        
    # Insert Visual Typesz
    for vt in visual_types:
        db.add(VisualType(type_name=vt)) """
    
    
    db.commit()

    # Insert Indicators
    for ind in indicators:
        db.add(Indicator(indicator_name=ind,business_domain_id =5))
    db.commit()


def create_visual_group_from_db():
    db = SessionLocal()
    group = VisualGroup(group_name="Sales Metrics", business_domain_id=5)
    db.add(group)
    db.commit()
    db.refresh(group)
    
    # Retrieve visual types and indicators from the database
    visual_types = db.query(VisualType).all()
    indicators = db.query(Indicator).all()
    
    # Example of using the first visual type and indicator from the database
    visuals_data = [
        {
            "type": visual_types[0].type_name,  # Use dynamic value
            "indicator": indicators[0].indicator_name,  # Use dynamic value
            "data": {"value": 1000, "target": 8000, "trend": 0.0},
            "title": indicators[0].indicator_name,
            "position": 2,
            "priority": 1
        },
        # Add more visuals as needed
    ]
    x_data = [["M1", "M2", "M3"], ["Q1", "Q2", "Q3"], ["Segment A", "Segment B", "Segment C"]]
    y_data = [[random.randint(10, 50) for _ in range(3)], [random.randint(10, 100) for _ in range(3)]]

    
    for _ in range(4):
        type = random.choice(visual_types)
        indicator = random.choice(indicators)
        visuals_data.append(
            {
            "type": type.type_name,
            "indicator": indicator.indicator_name,
            "data": {"x_data": random.choice(x_data), "y_data": random.choice(y_data)},
            "title": "Generated Visual",
            "position":1 if type=="kpi" else  random.randint(2, 4),
            "priority": random.randint(1, 3)
        })
    
    for visual_data in visuals_data:
        visual = Visual(
            group_id=group.id,
            type=visual_data["type"],
            indicator=visual_data["indicator"],
            data=visual_data["data"],
            title=visual_data["title"],
            position=visual_data["position"],
            priority=visual_data["priority"]
        )
        db.add(visual)
    
    db.commit()
    return {"message": "Visual group created dynamically from DB"}


populate_visual_types_and_indicators()

create_visual_group_from_db()