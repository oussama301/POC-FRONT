from sqlalchemy import Column, ForeignKey, Integer, JSON, String,Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from database_connection import engine
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from core.preTrain_NER_data import construire_et_evaluer_modele
from pydantic import BaseModel


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Définir la base
Base = declarative_base()

# Modèle pour les VisualFeatures
class VisualFeature(Base):
    __tablename__ = "visual_features"
    
    id = Column(Integer, primary_key=True, index=True)
    indicator = Column(String)
    visual_type = Column(String)
    data = Column(JSON)  # Stocke les données comme x_data, y_data, etc.
    title = Column(String)
    time = Column(String)
    position = Column(Integer)
    priority = Column(Integer)
    business_domain = Column(String)  # Domaine pour filtrer les visualisations

# Modèle pour les mots-clés
class Keyword(Base):
    __tablename__ = 'keywords'

    id = Column(Integer, primary_key=True, index=True)
    keyword_type = Column(String, index=True)  # Ex. "business_area", "time", "audience"
    keyword_value = Column(String, index=True)  # Ex. "sales", "monthly", "CEO"



# Modèle pour les groupes de visualisations
class VisualGroup(Base):
    __tablename__ = 'visual_groups'

    id = Column(Integer, primary_key=True, index=True)
    group_name = Column(String, index=True)
    business_domain_id = Column(Integer, ForeignKey('business_domains.id'))
    visuals = relationship("Visual", back_populates="group")
    business_domain = relationship("BusinessDomain", back_populates="visual_groups")

    def to_dict(self):
        return {
            "group_name": self.group_name,
            "visuals": [visual.to_dict() for visual in self.visuals]  # Utilisation de la méthode `to_dict` de Visual
        }

# Modèle pour les visualisations
class Visual(Base):
    __tablename__ = 'visuals'

    id = Column(Integer, primary_key=True, index=True)
    group_id = Column(Integer, ForeignKey('visual_groups.id'))
    type = Column(String, index=True)
    indicator = Column(String)
    data = Column(JSON)  # Stocke x_data, y_data, trend, etc. comme JSON
    title = Column(String)
    position = Column(Integer)
    priority = Column(Integer)

    group = relationship("VisualGroup", back_populates="visuals")

    def to_dict(self):
        return {
            "type": self.type,
            "indicator": self.indicator,
            "data": self.data,
            "title": self.title,
            "position": self.position,
            "priority": self.priority
        }
# Modèle pour les indicateurs
class Indicator(Base):
    __tablename__ = 'indicators'

    id = Column(Integer, primary_key=True, index=True)
    indicator_name = Column(String, unique=True, index=True)
    business_domain_id = Column(Integer, ForeignKey('business_domains.id'))
    level = Column(Integer, nullable=False)  # Ajout de la colonne level
    business_domain = relationship("BusinessDomain", back_populates="indicators")

# Modèle pour les dimensions
class Dimension(Base):
    __tablename__ = 'dimensions'

    id = Column(Integer, primary_key=True, index=True)
    dim_name = Column(String, unique=True, index=True)
    business_domain_id = Column(Integer, ForeignKey('business_domains.id'))
    level = Column(Integer, nullable=False)  # Ajout de la colonne level
    data = Column(JSON, nullable=True)  # Données JSON pour stocker les valeurs de la dimension
    business_domain = relationship("BusinessDomain", back_populates="dimensions")

# Modèle pour les types de visualisation
class VisualizationType(Base):
    __tablename__ = 'visual_types'

    id = Column(Integer, primary_key=True, index=True)
    type_name = Column(String, unique=True, index=True)  # Correction pour utiliser type_name
    category = Column(String, nullable=True)
    dimensions_types = Column(String, nullable=True)  # Ex : one_dimension, two_dimension, etc.
    level = Column(Integer, nullable=False)  # Ajout de la colonne level
    statut = Column(String, nullable=False)
  

# Modèle pour les domaines métiers
class BusinessDomain(Base):
    __tablename__ = 'business_domains'

    id = Column(Integer, primary_key=True, index=True)
    business_domain_name = Column(String, unique=True, index=True)
    indicators = relationship("Indicator", back_populates="business_domain")
    dimensions = relationship("Dimension", back_populates="business_domain")
    visual_groups = relationship("VisualGroup", back_populates="business_domain")


class IndicatorsNew(Base):
    __tablename__ = 'indicators_new'

    id = Column(Integer, primary_key=True, autoincrement=True)
    indicator_name = Column(String, nullable=False)
    business_domain_id = Column(Integer, ForeignKey('business_domains.id'), nullable=False)
    one_dimension = Column(Boolean, nullable=False, default=False)
    two_dimension = Column(Boolean, nullable=False, default=False)
    three_dimension = Column(Boolean, nullable=False, default=False)
    ind_type = Column(String, nullable=False)
    level = Column(Integer, nullable=False)

    def __repr__(self):
        return (
            f"<IndicatorsNew(id={self.id}, indicator_name='{self.indicator_name}', "
            f"business_domain_id={self.business_domain_id}, one_dimension={self.one_dimension}, "
            f"two_dimension={self.two_dimension}, three_dimension={self.three_dimension}, "
            f"ind_type='{self.ind_type}', level={self.level})>"
        )

# Créer toutes les tables
Base.metadata.create_all(bind=engine)
# model/model.py

