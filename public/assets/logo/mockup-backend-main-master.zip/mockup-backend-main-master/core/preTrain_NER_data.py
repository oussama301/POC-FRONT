import spacy  # SpaCy pour le traitement du langage naturel
from spacy.training import Example
from spacy.training.iob_utils import offsets_to_biluo_tags  # Utilisé pour gérer les entités BILUO
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split  # Pour diviser les données en ensembles d'entraînement et de test
import pandas as pd
import json
import os
import random
import warnings

# Ignorer les avertissements de type FutureWarning
warnings.filterwarnings("ignore", category=FutureWarning)

# Définir les étiquettes d'entités personnalisées
etiquettes = ['Role', 'Location', 'Time', 'Dimension', 'VisualizationType', 'Action', 'Indicator', 'BusinessDomain']

# Fonction pour supprimer les entités qui se chevauchent
def supprimer_chevauchements(entites):
    entites_triees = sorted(entites, key=lambda x: (x[0], x[1]))
    entites_filtrees = []
    dernier_end = -1
    for start, end, label in entites_triees:
        if start >= dernier_end: 
            entites_filtrees.append((start, end, label))
            dernier_end = end
    return entites_filtrees

# Fonction pour évaluer le modèle avec précision, rappel, F1 et matrice de confusion simplifiée
def evaluation_modele(nlp, donnees_test):
    true_labels = []
    pred_labels = []
    for texte, annotations in donnees_test:
        doc = nlp(texte["text"].lower())
        entites_filtrees = supprimer_chevauchements(annotations.get("entities", []))
        
        vrais_biluo_tags = offsets_to_biluo_tags(doc, entites_filtrees)
        pred_biluo_tags = [token.ent_iob_ + '-' + token.ent_type_ if token.ent_iob_ != 'O' else 'O' for token in doc]
        
        # Mapper les étiquettes pour obtenir leur forme de base 
        true_labels.extend([tag.split('-')[-1] if tag != 'O' else 'O' for tag in vrais_biluo_tags])
        pred_labels.extend([tag.split('-')[-1] if tag != 'O' else 'O' for tag in pred_biluo_tags])
    
    precision = precision_score(true_labels, pred_labels, average='weighted', zero_division=0)
    recall = recall_score(true_labels, pred_labels, average='weighted', zero_division=0)
    f1 = f1_score(true_labels, pred_labels, average='weighted', zero_division=0)
    # Matrice de confusion
    labels = sorted(set(true_labels + pred_labels) - {'O'})  # Exclure 'O' si non souhaité dans la matrice
    matrice_confusion = confusion_matrix(true_labels, pred_labels, labels=labels)
    matrice_confusion_df = pd.DataFrame(matrice_confusion, index=labels, columns=labels)

    return precision, recall, f1, matrice_confusion_df

# Fonction pour entraîner et évaluer le modèle
def construire_et_evaluer_modele(donnees_train, donnees_test, nombre_iterations=10, taux_dropout=0.3):
    nlp = spacy.blank("en")
    ner = nlp.add_pipe("ner", last=True)
    
    # Ajouter les étiquettes d'entités personnalisées
    for etiquette in etiquettes:
        ner.add_label(etiquette)
    
    optimizer = nlp.begin_training()
    for iteration in range(nombre_iterations):
        random.shuffle(donnees_train)
        pertes = {}
        
        # Utiliser des mini-lots pour des itérations plus rapides
        for batch_start in range(0, len(donnees_train), 16):
            batch_end = batch_start + 16
            batch = donnees_train[batch_start:batch_end]
            exemples = []
            for texte, annotations in batch:
                # Supprimer les entités qui se chevauchent
                annotations["entities"] = supprimer_chevauchements(annotations.get("entities", []))
                exemples.append(Example.from_dict(nlp.make_doc(texte["text"].lower()), annotations))
            nlp.update(exemples, drop=taux_dropout, losses=pertes, sgd=optimizer)
        
        print(f"Iteration {iteration + 1}, Perte : {sum(pertes.values())}")
    
    # Sauvegarder le modèle dans './core/dash_model'
    if not os.path.exists('./core/dash_model'):
        os.makedirs('./core/dash_model')
    nlp.to_disk('./core/dash_model')
    print("Modèle entraîné et enregistré dans le dossier './core/dash_model'")
    
    # Évaluer le modèle
    precision, recall, f1, matrice_confusion_df = evaluation_modele(nlp, donnees_test)
    
    return precision, recall, f1, matrice_confusion_df

# Charger les données d'entraînement à partir du fichier
with open('./core/prepa/spacy_training_data24.json', 'r') as fichier:
    donnees_entrainement = json.load(fichier)

# Diviser les données en ensembles d'entraînement et de test (80% / 20%)
donnees_train, donnees_test = train_test_split(donnees_entrainement, test_size=0.2, random_state=42)

# Sauvegarder les ensembles d'entraînement et de test
with open('./core/prepa/train_data.json', 'w') as fichier_train:
    json.dump(donnees_train, fichier_train, ensure_ascii=False, indent=4)
with open('./core/prepa/test_data.json', 'w') as fichier_test:
    json.dump(donnees_test, fichier_test, ensure_ascii=False, indent=4)

# Entraîner et évaluer le modèle
precision, recall, f1, matrice_confusion_df = construire_et_evaluer_modele(donnees_train, donnees_test)
print(f"\nPrécision : {precision}\nRappel : {recall}\nScore F1 : {f1}")
print("\nMatrice de Confusion :\n", matrice_confusion_df)

#  Afficher la matrice de confusion sous forme de graphique
ConfusionMatrixDisplay(confusion_matrix=matrice_confusion_df.values, display_labels=matrice_confusion_df.columns).plot()

# Exporter les résultats vers un fichier Excel
metrics = {
    'Précision': [precision],
    'Rappel': [recall],
    'F1 Score': [f1]
}
metrics_df = pd.DataFrame(metrics)

with pd.ExcelWriter('resultats_evaluation25.xlsx', engine='openpyxl') as writer:
    metrics_df.to_excel(writer, sheet_name='Metrics', index=False) 
    matrice_confusion_df.to_excel(writer, sheet_name='Confusion Matrix')  

print("Résultats exportés dans le fichier 'resultats_evaluation25.xlsx'.")
