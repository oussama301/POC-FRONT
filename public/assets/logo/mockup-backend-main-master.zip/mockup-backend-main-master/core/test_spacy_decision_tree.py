import spacy
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report
import json

# Charger le modèle SpaCy pré-entraîné
nlp = spacy.load('./core/dash_model')  # Chemin vers votre modèle SpaCy

# Fonction pour extraire les entités d'un texte et créer des caractéristiques binaires
def extraire_caracteristiques_avec_spacy(donnees):
    features = []
    labels = []
    
    for texte, annotations in donnees:
        doc = nlp(texte["text"])  # Utiliser le modèle SpaCy pour détecter les entités
        
        # Initialiser les caractéristiques binaires pour chaque type d'entité
        feature = {etiquette: 0 for etiquette in ['Role', 'Location', 'Time', 'Dimension', 
                                                  'VisualizationType', 'Action', 'Indicator', 'BusinessDomain']}
        
        # Mettre à jour les caractéristiques binaires en fonction des entités détectées
        for ent in doc.ents:
            if ent.label_ in feature:
                feature[ent.label_] = 1  # Marquer la présence de chaque entité détectée
        
        # Ajouter le label de la première entité annotée, ou "None" si aucune n'est présente
        if annotations["entities"]:
            labels.append(annotations["entities"][0][2])  # Utiliser la première étiquette d'entité comme label
        else:
            labels.append("None")  # Classe par défaut si aucune entité n'est présente
        
        features.append(list(feature.values()))  # Convertir le dictionnaire en liste de valeurs
    
    return features, labels

# Charger les données
with open('./core/prepa/spacy_training_data24.json', 'r') as fichier:
    donnees_entrainement = json.load(fichier)

# Extraire les caractéristiques et les labels
features, labels = extraire_caracteristiques_avec_spacy(donnees_entrainement)

# Diviser les données en ensembles d'entraînement et de test
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# Entraîner un modèle Decision Tree avec pondération des classes
clf = DecisionTreeClassifier(class_weight='balanced', random_state=42)
clf.fit(X_train, y_train)

# Évaluer le modèle sur l'ensemble de test
y_pred = clf.predict(X_test)
print("Rapport de classification (test set) :")
print(classification_report(y_test, y_pred))

# Validation croisée pour évaluer la robustesse du modèle
scores = cross_val_score(clf, features, labels, cv=5)
print(f"\nScores de validation croisée (5-fold) : {scores}")
print(f"Score moyen de validation croisée : {scores.mean()}")