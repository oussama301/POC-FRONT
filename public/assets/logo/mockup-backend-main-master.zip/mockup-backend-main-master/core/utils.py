from sqlalchemy import create_engine, MetaData, Table
from sqlalchemy.orm import sessionmaker
from spacy import displacy
from spacy.training import offsets_to_biluo_tags
import json
import spacy
DATABASE_URL = "postgresql://front:password@localhost/dash"

# Set up the SQLAlchemy engine and session
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
metadata = MetaData()
training_data_table = Table('training_data', metadata, autoload_with=engine)

def fetch_training_data():
    with SessionLocal() as session:
        # Select all rows from the training_data table using .mappings()
        result = session.execute(training_data_table.select()).mappings().all()

        # Convert the fetched data into SpaCy format
        training_data = []
        for row in result:
            text = row['text']
            annotations = row['annotations']
            training_data.append((text, annotations))

        return training_data

# Load blank SpaCy model
nlp = spacy.blank("en")

# Add NER component
ner = nlp.add_pipe("ner")

# Add labels (modify according to your custom entities)
ner.add_label("AUDIENCE")
ner.add_label("TIME")
ner.add_label("BUSINESS_AREA")

# Fetch and print the training data
train_data = fetch_training_data()
# Assuming your train_data is defined
for text, annotations in train_data:
    # Create a SpaCy document
    doc = nlp.make_doc(text)
    # Get BILUO tags for the provided entities
    entities = [(ent['start'], ent['end'], ent['label']) for ent in annotations['entities']]


#print(train_data)

