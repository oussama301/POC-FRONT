import json


# Load your exported JSON file
with open('c:/Users/mamdo/Downloads/mockup-backend-main/core/prepa/AiDash.json', 'r') as file:
    labeled_data = json.load(file)

# Convert the data to spaCy format
training_data = []

for item in labeled_data:
    text = item['data']
    entities = []
    for annotation in item['annotations'][0]['result']:
        start = annotation['value']['start']
        end = annotation['value']['end']
        label = annotation['value']['labels'][0]
        entities.append((start, end, label))
    training_data.append((text, {'entities': entities}))

# Save the data in spaCy format for training
with open('./core/prepa/spacy_training_data24.json', 'w') as output_file:
    json.dump(training_data, output_file)

# Sample Output (spaCy format)
# [('As the Sales Director, I need the weekly performance metrics for our e-commerce platform.',
#   {'entities': [(7, 20, 'Role'), (28, 34, 'Time'), (61, 79, 'BusinessDomain')]}),
#  ...]
