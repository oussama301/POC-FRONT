from fastapi import  APIRouter, Form, Depends
from fastapi import FastAPI, HTTPException
from sqlalchemy.orm import Session
import spacy
from routes.utils import visuals_group_from_random, get_all_visual_groups,create_visual_group,extract_features_from_prompt,generate_visuals, create_visual_group_in_db, get_all_visual_groups1
from visual_service import compare_features_with_keywords, get_visual_features, get_visuals_by_domain
from model.model import BusinessDomain, SessionLocal, VisualFeature, VisualGroup
from pydantic import BaseModel
from typing import List
import logging
from sqlalchemy import engine
from routes.utils import process_prompt  # Importation de la fonction depuis utils.py
from core.preTrain_NER_data import construire_et_evaluer_modele

 
app = FastAPI()

class TextPrompt(BaseModel):
    text: str

logging.basicConfig(level=logging.INFO)


# Data model to receive visual feature data
class Visual(BaseModel):
    type: str
    data: dict  # Data to be plotted
    title: str
    indicator :str
    position: int
    priority: int

# Load your trained custom model
nlp = spacy.load("./core/dash_model")
#nlp = spacy.load("en_core_web_sm")  # Load the SpaCy model
router = APIRouter()
# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
app = FastAPI() 
@router.post("/process")
async def process(text: str = Form(...), db: Session = Depends(get_db)):
    logging.info(f"Received text: {text}")
    # Parse the text using the SpaCy model
    doc = nlp(text)
    print(doc)
    # Extract features from the user prompt
    features = {
        "role": [],
        "time": [],
        "businessarea": [],
        "businessdomain": [],
        "indicator": [],
        "dimension":[],
        "data_visualization_approach": []
    }
    business_domain=None
    role =None
    # Collect entities based on the SpaCy model labels
    for ent in doc.ents:
        label = ent.label_.lower()
        if label in features:
            features[label].append(ent.text)
        if label == "businessdomain":  # Adjust based on your SpaCy model
            business_domain = ent.text.lower()
        if label == "role":  # Adjust based on your SpaCy model
            role = ent.text.lower()
    print(features)
    if not business_domain:
        return {"error": "Business domain not identified"}
        # Compare extracted features with keywords in the database
    visuals_from_db =  get_visual_groups(db=db, businessdomain=business_domain)# get_visuals_by_domain(db, business_domain,role)

    if not visuals_from_db:
        return {"error": "No visuals found for this business domain"}
    # Build suggestion based on features matched with indicators db
    # visual_suggestions = {
    #     "visual_type": "line_chart" if matched_keywords["time"] else "bar_chart",
    #     "matched_keywords": matched_keywords
    # }

    # # Store the visual suggestions in the database
    # visual_feature = VisualFeature(features=visual_suggestions)
    # db.add(visual_feature)
    # db.commit()
    # db.refresh(visual_feature)
    
    # Return the visual suggestions as a JSON response
     # Convert database entries to response format
    
    
    print(visuals_from_db)
    return visuals_from_db
    visual_groups = [
        
        {
            "group_name": "Sales Metrics",
            "visuals": [
                {
                    "type": "kpi",
                    "indicator": "TOTAL Sales",
                    "data": {
                        "value": 1000,
                        "target": 8000,
                        "trend": 0.0,
                    },
                    "title": "TOTAL Sales",
                    "position": 2,
                    "priority": 1,
                },
                {
                    "type": "bar_chart",
                    "indicator": "Monthly Sales",
                    "data": {
                        "x_data": ["M1", "M2", "M3"],
                        "y_data": [10, 20, 30],
                    },
                    "title": "Monthly Sales",
                    "position": 2,
                    "priority": 1,
                },
                {
                    "type": "line_chart",
                    "indicator": "Quarterly Sales",
                    "data": {
                        "x_data": ["Q1", "Q2", "Q3"],
                        "y_data": [10, 20, 30],
                    },
                    "title": "Quarterly Sales",
                    "position": 1,
                    "priority": 1,
                },
                {
                    "type": "pie_chart",
                    "indicator": "Customer Segmentation",
                    "data": {
                        "x_data": ["Segment A", "Segment B", "Segment C"],
                        "y_data": [40, 30, 30],
                    },
                    "title": "Customer Segmentation",
                    "position": 1,
                    "priority": 2,
                },
            ],
        },
        {
            "group_name": "Customer Insights",
            "visuals": [
                {
                    "type": "pie_chart",
                    "indicator": "Customer Segmentation",
                    "data": {
                        "x_data": ["Segment A", "Segment B", "Segment C"],
                        "y_data": [40, 30, 30],
                    },
                    "title": "Customer Segmentation",
                    "position": 1,
                    "priority": 2,
                },
                {
                    "type": "bar_chart",
                    "indicator": "Yearly Growth",
                    "data": {
                        "x_data": ["2021", "2022", "2023"],
                        "y_data": [20, 35, 50],
                    },
                    "title": "Yearly Growth",
                    "position": 1,
                    "priority": 1,
                },
            ],
        },
        {
            "group_name": "Market Trends",
            "visuals": [
                {
                    "type": "bar_chart",
                    "indicator": "Yearly Growth",
                    "data": {
                        "x_data": ["2021", "2022", "2023"],
                        "y_data": [20, 35, 50],
                    },
                    "title": "Yearly Growth",
                    "position": 1,
                    "priority": 1,
                },
                {
                    "type": "bar_chart",
                    "indicator": "Yearly Growth",
                    "data": {
                        "x_data": ["2021", "2022", "2023"],
                        "y_data": [20, 35, 50],
                    },
                    "title": "Yearly Growth",
                    "position": 1,
                    "priority": 1,
                },
            ],
        },
    ]
    
    #return visual_groups

@router.post("/process_random")
async def process(text: str = Form(...), db: Session = Depends(get_db)):
    logging.info(f"Received text: {text}")
    # Parse the text using the SpaCy model
    doc = nlp(text)
    print(doc)
    # Extract features from the user prompt
    features = {
        "role": [],
        "time": [],
        "businessarea": [],
        "businessdomain": [],
        "indicator": [],
        "dimension":[],
        "data_visualization_approach": []
    }
    business_domain=None
    role =None
    # Collect entities based on the SpaCy model labels
    for ent in doc.ents:
        label = ent.label_.lower()
        if label in features:
            features[label].append(ent.text)
        if label == "businessdomain":  # Adjust based on your SpaCy model
            business_domain = ent.text.lower()
        if label == "role":  # Adjust based on your SpaCy model
            role = ent.text.lower()
    print(features)
    if not business_domain:
        return {"error": "Business domain not identified"}
        # Compare extracted features with keywords in the database
    #   create_visual_group_from_random(db)# get_visuals_by_domain(db, business_domain,role)
    visuals_from_db =  get_all_visual_groups(db)
    if not visuals_from_db:
        return {"error": "No visuals found for this business domain"}
    
    
    print(visuals_from_db)
    return visuals_from_db
    

@router.get("/features/{feature_id}")
async def get_feature(feature_id: int, db: Session = Depends(get_db)):
    visual_feature = db.query(VisualFeature).filter(VisualFeature.id == feature_id).first()
    if visual_feature is None:
        return {"error": "Feature not found"}
    return visual_feature.features

@router.get("/core/generate_model")
async def generate_model():
    build_model()
    return "model built"

@router.get("/explore/visual_groups")
def get_visual_groups(businessdomain:str = "sales", db: Session = Depends(get_db)):
    businessdomain  = db.query(BusinessDomain).filter(BusinessDomain.business_domain_name == businessdomain).first()
    if businessdomain :
        groups = db.query(VisualGroup).filter(VisualGroup.business_domain ==businessdomain).all()
    else : 
        groups = db.query(VisualGroup).all()
    
    result = []
    for group in groups:
        group_data = {
            "group_name": group.group_name,
            "visuals": []
        }
        for visual in group.visuals:
            visual_data = {
                "type": visual.type,
                "indicator": visual.indicator,
                "data": visual.data,
                "title": visual.title,
                "position": visual.position,
                "priority": visual.priority
            }
            group_data["visuals"].append(visual_data)
        
        result.append(group_data)
    
    return result
##############################*code poc*#################################################"
########################################################################################################################################    
@app.post("/api/visuals/random")
async def generate_random_visual_group():
    """
    Génère un groupe de visualisations basé sur des types et des indicateurs choisis aléatoirement.
    """
    try:
        # Appel de la fonction pour générer un groupe de visualisations
        visual_group = visuals_group_from_random(engine)

        if visual_group is None:
            raise HTTPException(
                status_code=500, detail="Erreur lors de la génération du groupe de visualisations"
            )

        return {
            "message": "Groupe de visualisations généré avec succès",
            "visual_group": visual_group,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))




@router.post("/visuals/create_group/")
async def create_group(group_name: str, visuals_data: list, db: Session = Depends(get_db)):
    """
    Route pour créer un groupe de visualisations.
    """
    try:
        visual_group = create_visual_group(db, group_name, visuals_data)
        return {
            "message": "Groupe de visualisations créé avec succès",
            "data": visual_group.to_dict()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
###################################################################################################################################


@app.post("/generate_visuals/")
async def create_group(request: dict, db: Session = Depends(get_db)):
    """
    Route pour générer dynamiquement des visualisations à partir d'un prompt utilisateur.
    """
    try:
        # Appel de la fonction de traitement du prompt
        result = process_prompt(request['text'])  # Traitement du prompt utilisateur
        
        # Retourner les résultats sous forme de réponse JSON
        return {"message": "Visualisations générées avec succès", "data": result}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    #######################################################################################################################

@router.post("/process1")
async def process1(text: str = Form(...), db: Session = Depends(get_db)):
    """
    Endpoint to process the prompt, deduce business domain, and dynamically generate visuals.
    """
    # Step 1: Extract features using NLP
    business_domain, features = extract_features_from_prompt(text)

    if not business_domain:
        return {"error": "Business domain not identified"}

    # Handle "time" as a special case
    if business_domain.lower() == "time":
        business_domain = "sales"  # Reassign "time" to "sales"

    # Step 2: Dynamically generate visuals
    visuals = generate_visuals(db, features)

    # Step 3: Save the generated visuals to a new group in the database
    group = create_visual_group_in_db(db, f"{business_domain.capitalize()} Group", visuals)

    # Step 4: Return the newly created visual group
    return {"business_domain": business_domain, "visual_groups": [group]}