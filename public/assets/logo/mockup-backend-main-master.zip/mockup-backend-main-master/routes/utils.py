#######################################################################################################################################
#                                           Code updated by Hajar Mamdouh                                     
#                                           Last modification: 22/01/2025 
#                                                  Description:                                                                      
#                     - This script contains various functions related to data processing and visualization.                                    
#######################################################################################################################################

import random
from core.preTrain_NER_data import construire_et_evaluer_modele
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import spacy
from fastapi import FastAPI
from model.model import VisualizationType, Dimension, BusinessDomain,IndicatorsNew
import ast


app = FastAPI()
nlp = spacy.load("./core/dash_model")
class PromptRequest(BaseModel):
    text: str


def map_entities(doc):
    return {
        "BusinessDomain": next((ent.text for ent in doc.ents if "business" in ent.label_.lower()), None),
        "Role": next((ent.text for ent in doc.ents if "role" in ent.label_.lower()), None)
    }

def process_prompt_and_get_levels(db, prompt, nlp_model):
   
    doc = nlp_model(prompt)
    entities = map_entities(doc)

    business_domain_name = entities.get("BusinessDomain", "Sales")
    role = entities.get("Role", "CEO")

    business_domain = db.query(BusinessDomain).filter(
        BusinessDomain.business_domain_name.ilike(f"%{business_domain_name}%")
    ).first()

    if not business_domain:
        business_domain_name, role = "Sales", "CEO"
        business_domain = db.query(BusinessDomain).filter(
            BusinessDomain.business_domain_name.ilike(f"%{business_domain_name}%")
        ).first()

    if not business_domain:
        return {"status": "error", "message": f"Aucune donnée pour '{business_domain_name}'."}

    return {"domain": business_domain_name, "role": role}



def create_visual_groups(db, business_domain_name, role):
    
    business_domain = db.query(BusinessDomain).filter(
        BusinessDomain.business_domain_name.ilike(f"%{business_domain_name}%")
    ).first()

    if not business_domain:
        raise Exception(f"Domaine métier '{business_domain_name}' introuvable.")

    indicators = db.query(IndicatorsNew.indicator_name, IndicatorsNew.ind_type).all()
    dimensions = db.query(Dimension.dim_name, Dimension.data, Dimension.category).filter(
        Dimension.business_domain_id == business_domain.id
    ).all()

    visual_types = [
        {
            "type_name": vt.type_name,
            "statut": vt.statut,
            "level": vt.level
        }
        for vt in db.query(VisualizationType).filter(VisualizationType.statut == "OK").all()
    ]

    if not indicators or not dimensions:
        raise Exception("Indicateurs ou dimensions absents dans la base de données.")

    visual_groups = []

    for group_index in range(3):  
        group_name = f"{business_domain_name} Overview {group_index + 1}"
        visuals = []
        visuals.extend(generate_kpi_visuals(indicators, count=4))
        visuals.extend(generate_level_visuals(2, indicators, dimensions, visual_types, count=2))
        visuals.extend(generate_level_visuals(3, indicators, dimensions, visual_types, count=3))
        visual_groups.append({"group_name": group_name, "role": role, "visuals": visuals})

    return visual_groups


def generate_kpi_visuals(indicators, count):
    random.shuffle(indicators)
    return [
        { 
            "level": 1,
            "type": "KPI",
            "indicator": indicator_name,
            "ind_type": ind_type,
            "data": {"score": generate_score_for_kpi(ind_type)},
            "Order": random.randint(1, 4),
            
        }
        for indicator_name, ind_type in indicators[:count]
    ]
def generate_level_visuals(level, indicators, dimensions, visual_types, count):
   
    excluded_dimensions = {"amount", "quantity", "number"}

    temporal_dimensions = [
        (dim_name, dim_data, dim_category)
        for dim_name, dim_data, dim_category in dimensions
        if dim_category == "temporal" and dim_name.lower() not in excluded_dimensions
    ]

    filtered_dimensions = [
        (dim_name, dim_data, dim_category)
        for dim_name, dim_data, dim_category in dimensions
        if dim_category != "temporal" and dim_name.lower() not in excluded_dimensions
    ]

    valid_visual_types = [
        vt["type_name"] for vt in visual_types if vt.get("statut") == "OK" and vt.get("level") == level
    ]

    if not valid_visual_types:
        raise ValueError(f"Aucun type de visualisation valide disponible pour le niveau {level}.")

    visuals = []
    selected_types = set()

    for _ in range(count):
        indicator_name, ind_type = random.choice(indicators)

        available_types = list(set(valid_visual_types) - selected_types)

        if not available_types:
            selected_types.clear()
            available_types = valid_visual_types

        type_visual = random.choice(available_types)
        selected_types.add(type_visual)

        if type_visual.lower() == "line chart":
            if not temporal_dimensions:
                raise ValueError("Aucune dimension de catégorie 'temporal' disponible pour 'line chart'.")
            dim_name, dim_data, dim_category = random.choice(temporal_dimensions)

        elif type_visual.lower() == "radar chart":
            if len(filtered_dimensions) < 2:
                raise ValueError("Deux dimensions sont requises pour un radar chart comparatif.")
            radar_dimensions = random.sample(filtered_dimensions, 2)
            dim_name = f"{radar_dimensions[0][0]} vs {radar_dimensions[1][0]}"
            dim_data = [radar_dimensions[0][1], radar_dimensions[1][1]]
            dim_category = "comparative"
        
        else:
            if not filtered_dimensions:
                raise ValueError("Aucune dimension disponible pour les visualisations autres que 'line chart'.")
            dim_name, dim_data, dim_category = random.choice(filtered_dimensions)

        title = f"{indicator_name} by {dim_name}"

        visuals.append({
            "level": level,
            "title": title,
            "indicator": indicator_name,
            "ind_type": ind_type,
            "dimension": dim_name,
            "category": dim_category,
            "type_visuals": type_visual,
            "data": {
                "x_data": generate_x_data(dim_data),
                "y_data": generate_y_data(ind_type, len(generate_x_data(dim_data)))
            },
            "Order": random.randint(1, 4),
            "Level": level
        })

    return visuals

def generate_x_data(dimension_data):
    try:
        return ast.literal_eval(dimension_data) if isinstance(dimension_data, str) else dimension_data or []
    except (ValueError, SyntaxError):
        return []


def generate_y_data(ind_type, length):
    ranges = {
        "amount": (1000, 50000),
        "growth rate": (0, 100),
        "quantity": (1, 1000)
    }
    start, end = ranges.get(ind_type, (10, 100))
    return [
        random.randint(start, end) if ind_type != "growth rate" else round(random.uniform(start, end), 2)
        for _ in range(length)
    ]


def generate_score_for_kpi(ind_type):
    return generate_y_data(ind_type, 1)[0]
