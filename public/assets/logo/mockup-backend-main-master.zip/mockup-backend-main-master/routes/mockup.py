# routes/mockup.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
 
import logging

logging.basicConfig(level=logging.DEBUG)

# Create a FastAPI router instance
router = APIRouter()

# Define the input schema using Pydantic
class MockupRequest(BaseModel):
    prompt: str

@router.post("/generate-mockup")
async def generate_mockup(request: MockupRequest):
    prompt = request.prompt

    if not prompt:
        logging.error("Prompt cannot be empty.")
        raise HTTPException(status_code=400, detail="Prompt cannot be empty")
    
    logging.debug(f"Received prompt: {prompt}")

    try:
        # Generate the mockup using the AI model
        mockup = chat_gpt(prompt)

        # Log the result of the mockup generation
        logging.info(f"Generated mockup: {mockup}")

        # In the real app, replace this URL with the actual generated mockup
        mockup_url = "https://example.com/generated_mockup.png"

        return {"mockup_url": mockup_url}
    
    except Exception as e:
        logging.error(f"Error generating mockup: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate mockup")
