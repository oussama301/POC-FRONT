from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from database_connection import get_db
from routes.utils import map_entities, process_prompt_and_get_levels,create_visual_groups
from model.model import Indicator,VisualizationType, Dimension, BusinessDomain
from pydantic import BaseModel
import spacy
from routes.utils import PromptRequest
from fastapi import FastAPI, Depends, HTTPException,Query
from core.preTrain_NER_data import construire_et_evaluer_modele


# Chargement du modèle SpaCy pour le traitement du texte
nlp = spacy.load('./core/dash_model')

# Initialisation de l'application FastAPI
app = FastAPI()

# Configuration CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modèles Pydantic
class PromptRequest(BaseModel):
    text: str


# Modèle de requête pour l'API
class EntityRequest(BaseModel):
    business_domain_name: str
    level: int

# Endpoints pour tester l'API
@app.get("/")
def index():
    return {"message": "Hello, World!"}

@app.get("/test")
async def test_route():
    return {"message": "L'API fonctionne correctement"}

@app.post("/generate_visuals_from_db/")
async def generate_visuals_from_db(request: PromptRequest, db: Session = Depends(get_db)):
    try:
        prompt = request.text
        if not prompt:
            raise HTTPException(status_code=400, detail="Le prompt 'text' est requis.")
        print(f"Requête reçue : {prompt}")

        # Analyse NLP pour extraire les entités
        doc = nlp(prompt)
        entities = map_entities(doc)

        business_domain_name = entities.get("BusinessDomain", "Sales")
        role = entities.get("Role", "CEO")

        # Générer les Visual Groups
        visual_groups = generate_visual_groups(db, business_domain_name, role)
        if not visual_groups:
            raise HTTPException(status_code=404, detail="Aucune visualisation trouvée pour ce domaine.")

        return {
            "domain": business_domain_name,
            "role": role,
            "visual_groups": visual_groups
        }
    except Exception as e:
        print(f"Erreur : {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/extract-entities/")
async def extract_entities(request: PromptRequest):
    if not request.text:
        raise HTTPException(status_code=400, detail="Text cannot be empty")

    # Analyser le texte avec SpaCy
    doc = nlp(request.text)

    # Mapper les entités détectées
    result = map_entities(doc)

    return {"entities": result}

    ############################## Endpoint pour générer les Visual Groups basés sur un prompt.by hajar mamdouh ###########################################################

# Endpoint POST
@app.post("/generate_visual/")
async def generate_visual(request: PromptRequest, db: Session = Depends(get_db)):
  
    try:
        prompt = request.text
        if not prompt:
            raise HTTPException(status_code=400, detail="Le champ 'text' est requis dans la requête.")

        domain_data = process_prompt_and_get_levels(db, prompt, nlp)

        if "status" in domain_data and domain_data["status"] == "error":
            if domain_data["domain"] != "Sales":
                domain_data = process_prompt_and_get_levels(db, "Default sales prompt", nlp)

        business_domain_name = domain_data["domain"]
        role = domain_data["role"]
        visual_groups = create_visual_groups(db, business_domain_name, role)

        return {
            "domain": business_domain_name,
            "role": role,
            "visual_groups": visual_groups
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Une erreur est survenue : {str(e)}")