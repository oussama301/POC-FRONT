from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from routes import mockup,training
from fastapi.middleware.cors import CORSMiddleware
import logging
from fastapi.middleware.cors import CORSMiddleware
logging.basicConfig(level=logging.DEBUG)

origins = [
    "https://mockup-frontend-f1da978d3f7a.herokuapp.com",  # Replace with your frontend domain
    "http://localhost:8000",              # For local development
    "https://mockup-frontend-f1da978d3f7a.herokuapp.com//process_random",
]

def start_application():
    app = FastAPI(
        title="Mockup Dashboard backend APIs ",
        docs_url="/",
        description="Product by Sam Nac",
        version="0.0.1",
        swagger_ui_parameters={"defaultModelsExpandDepth": -1},
    )
    #create_tables()
    return app

app = start_application()
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Allows specified origins
    allow_credentials=True,
    allow_methods=["*"],     # Allows all HTTP methods
    allow_headers=["*"],     # Allows all headers
)
 
# Define the input schema using Pydantic
class MockupRequest(BaseModel):
    prompt: str

# Include the router from the mockup file
app.include_router(mockup.router)
app.include_router(training.router)

@app.get("/")
def index():
    return {"message": "Hello, World!"}

# Mount static files (for serving HTML templates)
#app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def read_index():
    with open("static/index.html", "r") as f:
        return f.read() 