
import requests

def publish_to_powerbi(mockup):
    powerbi_endpoint = 'https://api.powerbi.com/v1.0/myorg/'
    api_token = 'YOUR_POWER_BI_TOKEN'
    dataset_id = 'YOUR_DATASET_ID'

    url = f"{powerbi_endpoint}/datasets/{dataset_id}/pushRows"
    headers = {'Authorization': f'Bearer {api_token}'}
    data = {'mockup': mockup}

    response = requests.post(url, headers=headers, json=data)
    
    return response.json()
