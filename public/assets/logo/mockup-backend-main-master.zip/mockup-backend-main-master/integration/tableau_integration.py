
import requests

def publish_to_tableau(mockup):
    tableau_server = 'https://your-tableau-server.com'
    api_token = 'YOUR_TABLEAU_API_TOKEN'
    project_id = 'YOUR_PROJECT_ID'

    url = f"{tableau_server}/api/3.8/sites/{project_id}/workbooks"
    headers = {'X-Tableau-Auth': api_token}
    data = {'workbook': mockup}

    response = requests.post(url, headers=headers, json=data)
    
    return response.json()
